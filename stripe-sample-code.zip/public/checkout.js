// This is your test publishable API key.
const stripe = Stripe("pk_test_51T7log0mphHSzjJseGeqDszoeUuVspWSsV8hglMwR8MoeQZP0ghsgBO09hXmhCtGKieRcfqgckl7TZuuuVOnIJtx00o723KqAp");

initialize();

// Create a Checkout Session
async function initialize() {
  const fetchClientSecret = async () => {
    const response = await fetch("/create-checkout-session", {
      method: "POST",
    });
    const { clientSecret } = await response.json();
    return clientSecret;
  };

  const checkout = await stripe.initEmbeddedCheckout({
    fetchClientSecret,
  });

  // Mount Checkout
  checkout.mount('#checkout');
}